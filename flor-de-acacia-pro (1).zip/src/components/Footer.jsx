import React from 'react'

export default function Footer() {
  return (
    <footer className="bg-rose-900 text-rose-50 mt-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10 grid md:grid-cols-4 gap-8">
        <div>
          <div className="inline-flex items-center gap-2">
            <span className="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-white text-rose-700 font-bold">FA</span>
            <span className="font-extrabold text-lg tracking-tight font-brand">Flor de Acácia</span>
          </div>
          <p className="mt-3 text-rose-200 text-sm max-w-xs">
            Elegância acessível: bijuterias, acessórios e cuidados pessoais para realçar sua beleza todos os dias.
          </p>
        </div>
        <div>
          <h4 className="font-semibold">Loja</h4>
          <ul className="mt-3 space-y-2 text-rose-200 text-sm">
            <li>Bijuterias</li>
            <li>Maquiagem</li>
            <li>Acessórios</li>
            <li>Cuidados Pessoais</li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold">Ajuda</h4>
          <ul className="mt-3 space-y-2 text-rose-200 text-sm">
            <li>Entregas em Luanda</li>
            <li>Trocas e devoluções</li>
            <li>Perguntas frequentes</li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold">Contactos</h4>
          <ul className="mt-3 space-y-2 text-rose-200 text-sm">
            <li>WhatsApp: +244 900 000 000</li>
            <li>Instagram: @flordeacacia</li>
            <li>E-mail: contato@flordeacacia.co.ao</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-rose-800 py-4 text-center text-xs text-rose-300">
        © {new Date().getFullYear()} Flor de Acácia — Todos os direitos reservados.
      </div>
    </footer>
  )
}
