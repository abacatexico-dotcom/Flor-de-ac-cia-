import React from 'react'

export default function Rating({ value }) {
  const full = Math.round(value || 0)
  return (
    <div className="flex items-center gap-1 text-xs">
      {Array.from({ length: 5 }).map((_, i) => (
        <svg key={i} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" className={`h-4 w-4 ${i < full ? 'fill-yellow-400' : 'fill-gray-200'}`}>
          <path d="M12 .587l3.668 7.431 8.2 1.192-5.934 5.787 1.402 8.167L12 18.897 4.664 23.164l1.402-8.167L.132 9.21l8.2-1.192L12 .587z" />
        </svg>
      ))}
      <span className="text-gray-500">{Number(value || 0).toFixed(1)}</span>
    </div>
  )
}
