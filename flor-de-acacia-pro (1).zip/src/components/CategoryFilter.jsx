import React from 'react'
import { CATEGORIES } from '../data/products'

export default function CategoryFilter({ value, onChange }) {
  return (
    <div className="flex flex-wrap gap-2">
      {CATEGORIES.map(c => (
        <button
          key={c.id}
          onClick={() => onChange(c.id)}
          className={`rounded-2xl px-4 py-2 text-sm border transition ${value === c.id ? 'bg-rose-600 text-white border-rose-600 shadow' : 'bg-white border-rose-200 hover:shadow'}`}
        >
          {c.label}
        </button>
      ))}
    </div>
  )
}
