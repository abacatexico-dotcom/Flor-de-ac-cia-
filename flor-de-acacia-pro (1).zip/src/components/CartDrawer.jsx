import React from 'react'
import { useCart } from '../context/CartContext'
import { formatKz } from '../data/products'

export default function CartDrawer({ open, onClose }) {
  const { detailed, subtotal, setQty, remove } = useCart()
  const delivery = subtotal > 20000 ? 0 : 1500

  if (!open) return null
  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-black/40" onClick={onClose}></div>
      <div className="absolute right-0 top-0 h-full w-full sm:w-[420px] bg-white shadow-2xl p-5 flex flex-col">
        <div className="flex items-center justify-between">
          <h4 className="text-lg font-bold">Seu carrinho</h4>
          <button onClick={onClose} className="rounded-xl border px-3 py-1">Fechar</button>
        </div>
        <div className="mt-4 flex-1 overflow-auto space-y-4">
          {detailed.length === 0 && <p className="text-gray-500">Seu carrinho está vazio.</p>}
          {detailed.map(item => (
            <div key={item.id} className="flex gap-3 border border-rose-200 rounded-2xl p-3">
              <img src={item.product.images[0]} alt={item.product.name} className="h-20 w-20 rounded-xl object-cover" />
              <div className="flex-1">
                <div className="font-medium truncate">{item.product.name}</div>
                <div className="text-sm text-gray-500">{formatKz(item.product.price)}</div>
                <div className="mt-2 flex items-center gap-2">
                  <button onClick={() => setQty(item.id, Math.max(1, item.qty - 1))} className="rounded-lg border px-2">−</button>
                  <span className="text-sm">{item.qty}</span>
                  <button onClick={() => setQty(item.id, item.qty + 1)} className="rounded-lg border px-2">+</button>
                  <button onClick={() => remove(item.id)} className="ml-auto text-sm text-rose-600">Remover</button>
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="border-t pt-4 space-y-2">
          <div className="flex justify-between text-sm"><span>Subtotal</span><span>{formatKz(subtotal)}</span></div>
          <div className="flex justify-between text-sm"><span>Entrega</span><span>{formatKz(delivery)}</span></div>
          <div className="flex justify-between text-lg font-bold"><span>Total</span><span>{formatKz(subtotal + delivery)}</span></div>
          <button
            disabled={detailed.length === 0}
            onClick={() => alert('Pedido recebido! Entraremos em contacto pelo WhatsApp para finalizar o pagamento.')}
            className="w-full rounded-2xl bg-rose-600 px-5 py-3 text-white font-semibold shadow hover:shadow-md disabled:opacity-50"
          >
            Finalizar compra
          </button>
        </div>
      </div>
    </div>
  )
}
