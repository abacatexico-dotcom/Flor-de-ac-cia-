import React from 'react'

export default function Hero({ onPrimary }) {
  return (
    <section className="relative overflow-hidden">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 grid md:grid-cols-2 gap-6 items-center pt-8">
        <div className="order-2 md:order-1">
          <h2 className="text-3xl sm:text-4xl font-extrabold leading-tight font-brand">
            Elegância que floresce em você 🌸
          </h2>
          <p className="mt-3 text-gray-600">
            Peças delicadas, preços acessíveis e um visual moderno inspirado nas grandes lojas — do jeitinho Flor de Acácia.
          </p>
          <div className="mt-5 flex flex-wrap gap-3">
            <button onClick={onPrimary} className="rounded-2xl bg-rose-600 px-5 py-2 text-white font-medium shadow hover:shadow-md">
              Ver Bijuterias
            </button>
            <a href="#produtos" className="rounded-2xl border border-rose-300 bg-white px-5 py-2 font-medium hover:shadow">
              Promoções
            </a>
          </div>
          <div className="mt-6 flex items-center gap-4 text-sm text-gray-600">
            <div className="flex items-center gap-2"><span>🚚</span> Entrega em Luanda</div>
            <div className="flex items-center gap-2"><span>🔁</span> Troca em 7 dias</div>
            <div className="flex items-center gap-2"><span>💳</span> Paga na entrega</div>
          </div>
        </div>
        <div className="order-1 md:order-2">
          <div className="relative aspect-[4/3] rounded-3xl overflow-hidden shadow-lg">
            <img
              src="https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?q=80&w=1600&auto=format&fit=crop"
              alt="Coleção Flor de Acácia"
              className="h-full w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-rose-900/20 to-transparent"></div>
            <div className="absolute bottom-4 left-4 rounded-2xl bg-white/80 backdrop-blur px-4 py-2 text-sm shadow">
              Nova Coleção Primavera ✨
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
