import React from 'react'
import { Link } from 'react-router-dom'
import Rating from './Rating'
import { formatKz } from '../data/products'

export default function ProductCard({ p }) {
  return (
    <article className="group rounded-3xl overflow-hidden bg-white border border-rose-200 shadow-sm hover:shadow-md transition">
      <Link to={`/produto/${p.id}`} className="block">
        <div className="relative aspect-[4/5] overflow-hidden">
          <img src={p.images[0]} alt={p.name} className="h-full w-full object-cover group-hover:scale-105 transition" />
          {p.badge && (
            <span className="absolute left-3 top-3 rounded-full bg-white/90 backdrop-blur px-2 py-1 text-xs font-semibold border border-rose-200">
              {p.badge}
            </span>
          )}
        </div>
      </Link>
      <div className="p-3 md:p-4">
        <h4 className="font-semibold truncate">{p.name}</h4>
        <div className="mt-1"><Rating value={p.rating} /></div>
        <div className="mt-2 flex items-center justify-between">
          <span className="font-bold">{formatKz(p.price)}</span>
          <Link to={`/produto/${p.id}`} className="rounded-xl bg-rose-600 text-white px-3 py-1 text-sm hover:shadow">Ver</Link>
        </div>
      </div>
    </article>
  )
}
