import React, { useState } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { useCart } from '../context/CartContext'
import CartDrawer from './CartDrawer'

export default function Header() {
  const { items } = useCart()
  const [open, setOpen] = useState(false)
  const [params, setParams] = useSearchParams()
  const navigate = useNavigate()

  function onSearch(e) {
    const q = e.target.value
    setParams(p => { q ? p.set('q', q) : p.delete('q'); return p })
    if (location.pathname !== '/') navigate('/')
  }

  const count = items.reduce((s, i) => s + i.qty, 0)

  return (
    <header className="sticky top-0 z-40 backdrop-blur bg-rose-50/80 border-b border-rose-100">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-3 flex items-center gap-4">
        <Link to="/" className="flex items-center gap-2">
          <span className="inline-flex h-9 w-9 items-center justify-center rounded-2xl bg-brand-700 text-white font-bold">FA</span>
          <div>
            <div className="text-lg sm:text-xl font-extrabold tracking-tight font-brand">Flor de Acácia</div>
            <div className="text-xs text-gray-500 -mt-1">bijuterias & produtos femininos</div>
          </div>
        </Link>

        <div className="ml-auto flex items-center gap-2 w-full sm:w-auto">
          <div className="relative flex-1 sm:flex-none sm:w-96">
            <input
              defaultValue={params.get('q') ?? ''}
              onChange={onSearch}
              placeholder="Buscar: colar, batom, bolsa..."
              className="w-full rounded-2xl border border-rose-200 bg-white/80 px-4 py-2 pr-10 shadow-sm focus:outline-none focus:ring-2 focus:ring-rose-300"
            />
            <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">⌕</span>
          </div>

          <button
            onClick={() => setOpen(true)}
            className="relative rounded-2xl border border-rose-200 bg-white px-3 py-2 shadow-sm hover:shadow transition"
          >
            🛍️ <span className="ml-1 text-sm">Carrinho</span>
            {count > 0 && (
              <span className="absolute -top-2 -right-2 rounded-full bg-brand-700 text-white text-xs px-2 py-0.5">{count}</span>
            )}
          </button>
        </div>
      </div>
      <CartDrawer open={open} onClose={() => setOpen(false)} />
    </header>
  )
}
