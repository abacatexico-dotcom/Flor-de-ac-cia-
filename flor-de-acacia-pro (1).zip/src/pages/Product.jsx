import React from 'react'
import { useParams } from 'react-router-dom'
import { PRODUCTS, formatKz } from '../data/products'
import Rating from '../components/Rating'
import { useCart } from '../context/CartContext'
import ProductGrid from '../components/ProductGrid'

export default function Product() {
  const { id } = useParams()
  const p = PRODUCTS.find(p => p.id === id)
  const { add } = useCart()

  if (!p) return <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">Produto não encontrado.</div>

  const related = PRODUCTS.filter(x => x.category === p.category && x.id !== p.id).slice(0, 4)

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
      <div className="grid md:grid-cols-2 gap-6">
        <div className="relative aspect-[4/3] rounded-3xl overflow-hidden shadow">
          <img src={p.images[0]} alt={p.name} className="h-full w-full object-cover" />
        </div>
        <div>
          <h1 className="text-2xl font-extrabold">{p.name}</h1>
          <div className="mt-1"><Rating value={p.rating} /></div>
          <div className="mt-4 text-3xl font-extrabold">{formatKz(p.price)}</div>
          <p className="mt-4 text-gray-600">{p.description}</p>
          <div className="mt-6 flex gap-3">
            <button onClick={() => add(p.id)} className="rounded-2xl bg-rose-600 px-5 py-3 text-white font-semibold shadow hover:shadow-md">Adicionar ao carrinho</button>
            <a href="https://wa.me/244900000000" target="_blank" rel="noreferrer" className="rounded-2xl border border-rose-300 bg-white px-5 py-3 font-semibold hover:shadow">Pedir no WhatsApp</a>
          </div>
          <div className="mt-6 text-sm text-gray-600 flex items-center gap-4">
            <div>🚚 Entrega em Luanda</div>
            <div>🔁 Troca em 7 dias</div>
            <div>💳 Paga na entrega</div>
          </div>
        </div>
      </div>

      {related.length > 0 && (
        <div className="mt-16">
          <h2 className="text-xl font-bold mb-4">Você também pode gostar</h2>
          <ProductGrid items={related} />
        </div>
      )}
    </div>
  )
}
