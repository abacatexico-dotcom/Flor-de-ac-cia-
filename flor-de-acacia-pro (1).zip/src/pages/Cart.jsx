import React from 'react'
import { useCart } from '../context/CartContext'
import { formatKz } from '../data/products'

export default function Cart() {
  const { detailed, subtotal, setQty, remove } = useCart()
  const delivery = subtotal > 20000 ? 0 : 1500

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
      <h1 className="text-2xl font-extrabold mb-6">Carrinho</h1>
      {detailed.length === 0 ? (
        <p className="text-gray-600">Seu carrinho está vazio.</p>
      ) : (
        <div className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-4">
            {detailed.map(item => (
              <div key={item.id} className="flex gap-3 border border-rose-200 rounded-2xl p-3 bg-white shadow-soft">
                <img src={item.product.images[0]} alt={item.product.name} className="h-20 w-20 rounded-xl object-cover" />
                <div className="flex-1">
                  <div className="font-medium">{item.product.name}</div>
                  <div className="text-sm text-gray-500">{formatKz(item.product.price)}</div>
                  <div className="mt-2 flex items-center gap-2">
                    <button onClick={() => setQty(item.id, Math.max(1, item.qty - 1))} className="rounded-lg border px-2">−</button>
                    <span className="text-sm">{item.qty}</span>
                    <button onClick={() => setQty(item.id, item.qty + 1)} className="rounded-lg border px-2">+</button>
                    <button onClick={() => remove(item.id)} className="ml-auto text-sm text-rose-600">Remover</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <aside className="space-y-3 h-max p-5 bg-white border border-rose-200 rounded-3xl shadow-soft">
            <div className="flex justify-between text-sm"><span>Subtotal</span><span>{formatKz(subtotal)}</span></div>
            <div className="flex justify-between text-sm"><span>Entrega</span><span>{formatKz(delivery)}</span></div>
            <div className="flex justify-between text-lg font-bold"><span>Total</span><span>{formatKz(subtotal + delivery)}</span></div>
            <button
              className="w-full rounded-2xl bg-rose-600 px-5 py-3 text-white font-semibold shadow hover:shadow-md"
              onClick={() => alert('Pedido recebido! Entraremos em contacto pelo WhatsApp para finalizar o pagamento.')}
            >
              Finalizar compra
            </button>
            <a href="https://wa.me/244900000000" target="_blank" rel="noreferrer" className="block w-full text-center rounded-2xl border border-rose-300 bg-white px-5 py-3 font-semibold hover:shadow">
              Pedir no WhatsApp
            </a>
          </aside>
        </div>
      )}
    </div>
  )
}
