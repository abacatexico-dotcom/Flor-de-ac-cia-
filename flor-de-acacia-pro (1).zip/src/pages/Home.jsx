import React, { useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import Hero from '../components/Hero'
import CategoryFilter from '../components/CategoryFilter'
import ProductGrid from '../components/ProductGrid'
import { PRODUCTS } from '../data/products'

export default function Home() {
  const [category, setCategory] = useState('todas')
  const [params] = useSearchParams()
  const q = (params.get('q') || '').toLowerCase()

  const list = useMemo(() => {
    return PRODUCTS.filter(p => {
      const byCat = category === 'todas' || p.category === category
      const byQuery = !q || p.name.toLowerCase().includes(q)
      return byCat && byQuery
    })
  }, [category, q])

  return (
    <div>
      <Hero onPrimary={() => setCategory('bijuterias')} />
      <section id="produtos" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 mt-10 pb-24">
        <CategoryFilter value={category} onChange={setCategory} />
        <div className="flex items-end justify-between mb-4 mt-6">
          <h3 className="text-xl font-bold">Produtos</h3>
          <p className="text-sm text-gray-500">{list.length} item(s) encontrados</p>
        </div>
        <ProductGrid items={list} />
      </section>
    </div>
  )
}
