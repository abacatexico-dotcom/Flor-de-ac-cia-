export const CATEGORIES = [
  { id: 'todas', label: 'Todas' },
  { id: 'bijuterias', label: 'Bijuterias' },
  { id: 'maquiagem', label: 'Maquiagem' },
  { id: 'acessorios', label: 'Acessórios' },
  { id: 'cuidados', label: 'Cuidados Pessoais' },
]

export const PRODUCTS = [
  {
    id: 'colar-perolas',
    name: 'Colar Pérolas Aurora',
    price: 9500,
    category: 'bijuterias',
    badge: 'Novo',
    rating: 4.8,
    images: [
      'https://images.unsplash.com/photo-1603575449153-21f9b8100b52?q=80&w=1200&auto=format&fit=crop',
    ],
    description: 'Colar clássico com pérolas sintéticas de alto brilho e fecho hipoalergénico.',
  },
  {
    id: 'pulseira-acacia',
    name: 'Pulseira Acácia Dourada',
    price: 6900,
    category: 'bijuterias',
    badge: 'Best-seller',
    rating: 4.9,
    images: [
      'https://images.unsplash.com/photo-1599643477877-530eb83abc8e?q=80&w=1200&auto=format&fit=crop',
    ],
    description: 'Pulseira delicada com banho dourado, inspiração na flor de acácia.',
  },
  {
    id: 'brincos-lua',
    name: 'Brincos Meia-Lua',
    price: 5400,
    category: 'bijuterias',
    rating: 4.6,
    images: [
      'https://images.unsplash.com/photo-1617038260897-3e6f7bb39a09?q=80&w=1200&auto=format&fit=crop',
    ],
    description: 'Brincos leves em formato meia-lua para looks do dia a dia.',
  },
  {
    id: 'anel-aurora',
    name: 'Anel Aurora Cristal',
    price: 8800,
    category: 'bijuterias',
    badge: '-15%',
    rating: 4.7,
    images: [
      'https://images.unsplash.com/photo-1611669892152-71c8f2dc7b62?q=80&w=1200&auto=format&fit=crop',
    ],
    description: 'Anel com cristal central e micro zircónias, acabamento premium.',
  },
  {
    id: 'batom-rosado',
    name: 'Batom Rosado Soft-Matte',
    price: 3200,
    category: 'maquiagem',
    rating: 4.5,
    images: [
      'https://images.unsplash.com/photo-1611162618071-b39a2ecf2dd1?q=80&w=1200&auto=format&fit=crop',
    ],
    description: 'Batom com acabamento aveludado e longa duração.',
  },
  {
    id: 'paleta-cores',
    name: 'Paleta 12 Cores Vibrantes',
    price: 7400,
    category: 'maquiagem',
    badge: 'Novo',
    rating: 4.4,
    images: [
      'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?q=80&w=1200&auto=format&fit=crop',
    ],
    description: 'Paleta versátil para makes do dia a dia ao glam.',
  },
  {
    id: 'escova-cabelo',
    name: 'Escova Desembaraçante Flex',
    price: 4100,
    category: 'acessorios',
    rating: 4.3,
    images: [
      'https://images.unsplash.com/photo-1582092723384-5c15de92b6f6?q=80&w=1200&auto=format&fit=crop',
    ],
    description: 'Escova flexível que reduz a quebra e o frizz.',
  },
  {
    id: 'scrunchies',
    name: 'Kit 5 Scrunchies Seda',
    price: 2700,
    category: 'acessorios',
    rating: 4.2,
    images: [
      'https://images.unsplash.com/photo-1616628188462-8c2bd3a5a70e?q=80&w=1200&auto=format&fit=crop',
    ],
    description: 'Conjunto de elásticos de seda para proteger o cabelo.',
  },
  {
    id: 'bolsa-mini',
    name: 'Bolsa Mini Urbana',
    price: 12500,
    category: 'acessorios',
    badge: '-10%',
    rating: 4.7,
    images: [
      'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?q=80&w=1200&auto=format&fit=crop',
    ],
    description: 'Mini bolsa prática para o dia a dia, alça regulável.',
  },
  {
    id: 'hidra-acacia',
    name: 'Hidratante Flor de Acácia',
    price: 5200,
    category: 'cuidados',
    rating: 4.6,
    images: [
      'https://images.unsplash.com/photo-1585238342028-4bbc2c3b6d7a?q=80&w=1200&auto=format&fit=crop',
    ],
    description: 'Hidratante corporal perfumado com notas florais.',
  },
  {
    id: 'oleo-corporal',
    name: 'Óleo Corporal Lumina',
    price: 6100,
    category: 'cuidados',
    rating: 4.5,
    images: [
      'https://images.unsplash.com/photo-1585386959984-a415522316df?q=80&w=1200&auto=format&fit=crop',
    ],
    description: 'Óleo leve que nutre e dá brilho à pele.',
  },
  {
    id: 'necessaire',
    name: 'Nécessaire Impermeável',
    price: 3900,
    category: 'acessorios',
    rating: 4.1,
    images: [
      'https://images.unsplash.com/photo-1620042359380-537df7ce429d?q=80&w=1200&auto=format&fit=crop',
    ],
    description: 'Bolsa necessária com material resistente à água.',
  },
]

export function formatKz(n) {
  return n.toLocaleString('pt-AO', { style: 'currency', currency: 'AOA', maximumFractionDigits: 0 })
}
