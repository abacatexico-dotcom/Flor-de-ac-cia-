import React, { createContext, useContext, useMemo, useState } from 'react'
import { PRODUCTS } from '../data/products'

const CartCtx = createContext()

export function CartProvider({ children }) {
  const [items, setItems] = useState([]) // {id, qty}

  function add(id, qty = 1) {
    setItems(prev => {
      const found = prev.find(i => i.id === id)
      if (found) return prev.map(i => i.id === id ? { ...i, qty: i.qty + qty } : i)
      return [...prev, { id, qty }]
    })
  }
  function remove(id) { setItems(prev => prev.filter(i => i.id !== id)) }
  function setQty(id, qty) { setItems(prev => prev.map(i => i.id === id ? { ...i, qty: Math.max(1, qty) } : i)) }

  const detailed = useMemo(() => items.map(i => ({ ...i, product: PRODUCTS.find(p => p.id === i.id) })), [items])
  const subtotal = useMemo(() => detailed.reduce((s, i) => s + i.product.price * i.qty, 0), [detailed])

  return (
    <CartCtx.Provider value={{ items, add, remove, setQty, detailed, subtotal }}>
      {children}
    </CartCtx.Provider>
  )
}

export function useCart() {
  return useContext(CartCtx)
}
